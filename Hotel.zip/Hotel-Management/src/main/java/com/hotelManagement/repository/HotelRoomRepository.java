package com.hotelManagement.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelManagement.models.HotelRoom;

@Repository
public interface HotelRoomRepository extends MongoRepository<HotelRoom, String>{

	@Query("{ 'hotelId' : ?0 }")
	List<HotelRoom> viewHotelRoomByhotelId(String hotelId);

	@DeleteQuery
	void deleteByRoomId(String roomId);
}
