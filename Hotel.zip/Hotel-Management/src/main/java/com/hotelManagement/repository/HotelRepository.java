package com.hotelManagement.repository;


import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.HotelRoom;

@Repository
public interface HotelRepository extends MongoRepository<Hotel,String>{

	@DeleteQuery
	void deleteByHotelId(String hotelId);

	void save(HotelRoom r);
	//Hotel viewHotel(@Valid Hotel hotel);

}
