package com.hotelManagement.service;


import com.hotelManagement.models.Admin;
import com.hotelManagement.models.HotelRoom;

public interface IAdminService {
	public Admin searchById(String id);
	public  Admin create(Admin a) ;
	/*
	 * public Admin addHotel(@Valid Hotel hotel, BindingResult result); public Admin
	 * updateHotel(Hotel h); 
	 * public Admin deleteHotel(int id); 
	 */ 
	//public List<Admin> viewHotel();
	
	public Admin createRoom(HotelRoom h);
	
}
