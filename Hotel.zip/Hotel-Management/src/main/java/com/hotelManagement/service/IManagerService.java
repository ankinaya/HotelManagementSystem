package com.hotelManagement.service;

import com.hotelManagement.models.Manager;

public interface IManagerService {
	public void createManager(Manager m);

	public Manager findManager(String managerId);

	public void updateManagerDetails(String managerId);

}
