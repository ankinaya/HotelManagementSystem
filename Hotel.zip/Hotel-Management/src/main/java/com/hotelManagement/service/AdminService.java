package com.hotelManagement.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.HotelRoom;
import com.hotelManagement.repository.AdminRepository;

@Service
public class AdminService implements IAdminService {
	
	@Autowired
	AdminRepository adminRepository;

	public AdminService() {
		super();
	}

	@Override
	public Admin searchById(String id) {
		return adminRepository.findById(id).orElse(null);
	}

	@Override
	public Admin create(Admin a) {
		return adminRepository.save(a);
	}

	@Override
	public Admin createRoom(HotelRoom h) {
		// TODO Auto-generated method stub
		return adminRepository.save(h);
	}

	
	
	

}
