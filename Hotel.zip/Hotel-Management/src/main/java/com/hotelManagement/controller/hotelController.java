package com.hotelManagement.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.HotelBooking;
import com.hotelManagement.models.HotelRoom;
import com.hotelManagement.models.Manager;
import com.hotelManagement.models.User;
import com.hotelManagement.service.IAdminService;
import com.hotelManagement.service.IHotelService;
import com.hotelManagement.service.IManagerService;
import com.hotelManagement.service.IUserService;

@Controller
public class hotelController {

	@Autowired
	IHotelService hotelService;

	@Autowired
	IAdminService adminService;

	@Autowired
	IManagerService managerService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	IUserService userService;

	String pattern = "yyyy-MM-dd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));
	String currDate = simpleDateFormat.format(new Date());

	/* LOGIN PAGE */

	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public String login(@ModelAttribute("admin") Admin admin) {
//		System.out.println("hello.................");
		return "login";
	}

	/* LOGIN PAGE VALIDATION ACCORDING TO ROLE */

	@RequestMapping("/index")
	public String index(@ModelAttribute("admin") Admin admin, Model m, HttpSession httpSession) {
		System.out.println(admin.toString());
		System.out.println(admin);
		Admin a = adminService.searchById(admin.getUsername());
		// System.out.println("Hiii"+em);
		if (a != null) {
//			System.out.println(admin.getPassword()+a.getPassword());
			if (passwordEncoder.matches(admin.getPassword(), a.getPassword())) {

				httpSession.setAttribute("userId", admin.getUsername());
				if (a.getRole().equalsIgnoreCase("SUPERADMIN"))
					return "SuperAdminMenu";

				if (a.getRole().equalsIgnoreCase("ADMIN"))
					return "hotelMenu";

				if (a.getRole().equalsIgnoreCase("USER")) {
					List<Hotel> hotelList = hotelService.viewHotel();
					m.addAttribute("hotelList", hotelList);

					return "viewHotelForUser";
				}

			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "login";
			}

		} else {
			m.addAttribute("msg", "User doesn't Exist.");

		}

		return "login";
	}

	// SUPER ADMIN MENU
	
	// ADD HOTEL DETAILS

	@RequestMapping(method = RequestMethod.GET, path = "/addHoteDetails")

	public String addHotel(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel hotel, Model model) {

		return "addHotelform";
	}

	/* ADD MANAGER OF A HOTEL */

	@RequestMapping(method = RequestMethod.POST, path = "/addManagerDetails")

	public String addHotelDetails(@ModelAttribute("hotel") Hotel hotel, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
		session.setAttribute("hotelId", hotel.getHotelId());
		session.setAttribute("hotel", hotel);
		return "addManagerform";
	}

	/* AUTHENTICATE PASSWORD */

	@RequestMapping(method = RequestMethod.POST, path = "/setHotelPassword")

	public String addManagerDetails(@ModelAttribute("admin") Admin admin, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);

		manager.setManagerId(session.getAttribute("hotelId").toString());
		session.setAttribute("manager", manager);
		return "setHotelAuthentication";
	}

	/* STRORING DATA OF HOTEL, MANAGER TO A DATABASE */

	@RequestMapping(method = RequestMethod.POST, path = "/AddHotelFinal")

	public String addHotelFinal(@ModelAttribute("admin") Admin admin, Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);

		admin.setPassword(passwordEncoder.encode(admin.getPassword()));
		admin.setUsername(session.getAttribute("hotelId").toString());
		admin.setRole("Admin");
		Hotel hotel1 = (Hotel) session.getAttribute("hotel");
		System.out.println(hotel1);
		if (hotel1.getSubscriptionDate().compareTo(currDate) < 0)
			hotel1.setStatus(true);
		hotel1.setStatus(false);
		System.out.println("after update" + hotel1);
		System.out.println((Hotel) session.getAttribute("hotel"));
		hotelService.createHotel(hotel1);
		Manager manager1 = (Manager) session.getAttribute("manager");
		managerService.createManager(manager1);
		adminService.create(admin);
		model.addAttribute("msg", "Added Successfully!!");
		return "SuperAdminMenu";
	}

	/*
	 * // VIEW HOTEL
	 * 
	 * @RequestMapping(method= RequestMethod.GET,path="/viewHotels") public String
	 * viewHotel(@ModelAttribute("admin")Admin admin,Model model,HttpSession
	 * session) {
	 * 
	 * return "viewHotel"; }
	 * 
	 */
	@RequestMapping(value = "/viewHotel", method = RequestMethod.GET)
	public String getHotel(ModelMap m) {
		for (Hotel h : hotelService.viewHotel()) {
//			System.out.println("before"+h);
			if (h.getSubscriptionDate().compareTo(currDate) > 0) {
				h.setStatus(true);
				hotelService.createHotel(h);
			} else if (h.getSubscriptionDate().compareTo(currDate) < 0) {
				h.setStatus(false);
				hotelService.createHotel(h);
			}
		}
		List<Hotel> hotelList = hotelService.viewHotel();
		m.addAttribute("hotelList", hotelList);
		return "viewHotel";

	}

	// DELETE HOTEL
	@RequestMapping(method = RequestMethod.GET, value = "/deleteHotel")
	public String deleteHotel(@ModelAttribute("hotel") Hotel h, Model m, HttpSession session) {

		List<Hotel> hotel = hotelService.viewHotel();
		m.addAttribute("hotelList", hotel);
		session.setAttribute("hotelList", hotel);
		System.out.println(hotel);
		return "deleteHotel";
	}

	/*
	 * @RequestMapping(method = RequestMethod.POST, value = "/delete") public String
	 * delete(@ModelAttribute("hotel") Hotel hotel, Model m, HttpSession session) {
	 * System.out.println(hotel.getHotelId()); m.addAttribute("hotelList",
	 * session.getAttribute("hotelList")); Hotel h = hotel; if
	 * (hotelService.viewHotelByHotelId(hotel.getHotelId()) != null) {
	 * m.addAttribute("msg", " Hotel " + hotel.getHotelName() +
	 * " deleted Successfully"); hotelService.deleteByHotelId(hotel.getHotelId()); }
	 * else m.addAttribute("msg", "No! Hotel is not present with " +
	 * hotel.getHotelId() + " ID"); return "deleteHotel"; }
	 */
  
		@RequestMapping(method = RequestMethod.POST, value = "/delete")
			public String delete(@ModelAttribute("hotel") Hotel hotel, Model m, HttpSession session) {
				System.out.println(hotel.getHotelId());
				m.addAttribute("hotelList", session.getAttribute("hotelList"));
				Hotel h = hotelService.viewHotelByHotelId(hotel.getHotelId());
				if (h != null) {
					m.addAttribute("msg", " Hotel " + h.getHotelName() + " deleted Successfully");
					hotelService.deleteByHotelId(hotel.getHotelId());
				} else
					m.addAttribute("msg", "No! Hotel is not present with " + hotel.getHotelId() + " ID");
				return "deleteHotel";
			} 
		 


	@RequestMapping(method = RequestMethod.GET, value = "/editHotel")
	public String editHotel(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel h, Model m,
			HttpSession session) {

		List<Hotel> hotel = hotelService.viewHotel();
		m.addAttribute("hotelList", hotel);
		session.setAttribute("hotelList", hotel);
		System.out.println(hotel);
		return "EditHotel";
	}

	@RequestMapping(value = "/edithoteldetails", method = RequestMethod.POST)
	public String editHotelDetails(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel h,
			HttpSession session, Model model) {
		session.setAttribute("hotelId", h.getHotelId());
		if (hotelService.viewHotelByHotelId(h.getHotelId()) != null) {
			return "editHotelForm";
		} else {
			model.addAttribute("msg", " Cannot find such Hotel with " + h.getHotelId() + " ID!!");
			return "EditHotel";

		}
	}

	@RequestMapping(value = "/editHotelDetailsSaved", method = RequestMethod.POST)
	public String editHotelDetailsSaved(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel h,
			HttpSession session) {
		Hotel hotel = h;
		hotel.setHotelId((String) session.getAttribute("hotelId"));
		hotelService.createHotel(h);
		return "SuperAdminMenu";
	}

	// RENEW HOTEL SUBSCRIPTION
	@RequestMapping(value = "/renewalHotel", method = RequestMethod.GET)
	public String renewHotel(@ModelAttribute("hotel") Hotel h, Model model,HttpSession session) {
		List<Hotel> hotelList = hotelService.viewHotel();
		model.addAttribute("hotelList", hotelList);
		session.setAttribute("hotelList", hotelList);
		return "renewHotel";
	}

	@RequestMapping(value = "/renewHotelDate")
	public String renewHotelDate(@ModelAttribute("hotel") Hotel h, Model model,HttpSession session) {
		System.out.println(h.getHotelId());
		Hotel hotel = hotelService.viewHotelByHotelId(h.getHotelId());
		if(hotel!=null) {
		hotel.setSubscriptionDate(h.getSubscriptionDate());
		hotelService.createHotel(hotel);
		return "SuperAdminMenu";
	}
		else
		{
			model.addAttribute("hotelList", session.getAttribute("hotelList"));
			model.addAttribute("msg", " Cannot find such Hotel with " + h.getHotelId() + " ID!!");
			return "renewHotel";
		}
	}

	// ADMIN MENU
	// ADD HOTEL ROOMS
	@RequestMapping(method = RequestMethod.GET, path = "/addHotelRoom")
	public String addRoom(@ModelAttribute("hotelRoom") HotelRoom hotelroom) {

		return "addHotelRoom";

	}

	@RequestMapping(method = RequestMethod.POST, path = "/hotelRoom")
	public String room(@ModelAttribute("hotelRoom") HotelRoom hotelroom, Model model, HttpSession session) {
		hotelroom.setHotelId(session.getAttribute("userId").toString());
		hotelroom.setRoomAvailability(true);
		hotelroom.setRoomId(hotelroom.getHotelId() + "R" + hotelroom.getroomNo());
		System.out.println(hotelroom.toString());
		hotelService.createHotelRoom(hotelroom);
		// adminService.create(admin);
		model.addAttribute("msg", "Added Successfully!!");

		return "hotelMenu";
	}

	// VIEW HOTEL ROOMS
	@RequestMapping(method = RequestMethod.GET, value = "/viewHotelRoom")
	public String viewRoom(ModelMap m, HttpSession session) {
		List<HotelRoom> roomList = hotelService.viewHotelRoomByhotelId((String) session.getAttribute("userId"));
		m.addAttribute("roomList", roomList);

		return "viewHotelRoom";
	}

	// DELETE HOTEL ROOMS

	@RequestMapping(method = RequestMethod.GET, value = "/deleteHotelRoom")
	public String deleteRoom(@ModelAttribute("room") HotelRoom hotelroom, Model model) {

		List<HotelRoom> hotelroom1 = hotelService.viewHotelRooms();
		model.addAttribute("roomList", hotelroom1);
		return "deleteHotelRoom";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deleteRoom")
	public String delete(@ModelAttribute("room") HotelRoom hotelroom) {
		System.out.println(hotelroom.getRoomId());
		hotelService.deleteByRoomId(hotelroom.getRoomId());
		return "hotelMenu";
	}


	// USER

	// user registration
	@RequestMapping(value = "registerUser", method = RequestMethod.GET)
	public String RegisterUser(@ModelAttribute("user") User user) {
		return "userRegistration";
	}

	@RequestMapping(value = "registerUser/setPass", method = RequestMethod.POST)
	public String RegisterUser1(@ModelAttribute("user") User user, @ModelAttribute("admin") Admin admin,
			HttpSession session) {
		session.setAttribute("roomuser", user);
		return "userpasswordset";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String RegisterUser1(@ModelAttribute("admin") Admin admin, HttpSession session) {

		User user = (User) session.getAttribute("roomuser");
		admin.setUsername(user.getEmail());
		admin.setRole("User");
		userService.create(user);
		Admin admin1 = new Admin(admin.getUsername(), passwordEncoder.encode(admin.getPassword()), admin.getRole());
		adminService.create(admin1);
		return "redirect:/";
	}

	@RequestMapping(value = "/index/{hotelId}")
	public String showAllRoom(@PathVariable("hotelId") String hotelId, ModelMap m) {
		List<HotelRoom> roomList = hotelService.viewHotelRoomByhotelId(hotelId);
		m.addAttribute("roomList", roomList);
		return "viewHotelRoomUser";
	}

	@RequestMapping(value = "/index/{hotelId}/{roomId}")
	public String bookRoom(@PathVariable("hotelId") String hotelId, @PathVariable("roomId") String roomId,
			@ModelAttribute("hotelRoom") HotelRoom hotelRoom, @ModelAttribute("hotelbooking") HotelBooking hotelbooking,
			HttpSession session) {
		HotelRoom room = hotelService.viewHotelRoomByRoomId(roomId);
		hotelRoom.setroomNo(room.getroomNo());
		hotelRoom.setRoomType(room.getRoomType());
		hotelRoom.setRoomCategory(room.getRoomCategory());
		session.setAttribute("hotelId", hotelId);
		session.setAttribute("roomId", roomId);
		return "hotelbookingform";
	}

	@RequestMapping(value = "/bookingfinal", method = RequestMethod.POST)
	public String finalBooking(@ModelAttribute("hotelbooking") HotelBooking hotelbooking, HttpSession session,
			Model modal) {
		hotelbooking.setBookingNo("BK" + session.getAttribute("roomId"));
		hotelbooking.setRoomId((String) session.getAttribute("roomId"));
		hotelbooking.setUserEmailId((String) session.getAttribute("userId"));
		hotelbooking.setHotelId((String) session.getAttribute("hotelId"));
		System.out.println(hotelbooking);
		userService.bookingHotelRoom(hotelbooking);
		HotelRoom hotetroom = hotelService.viewHotelRoomByRoomId(hotelbooking.getRoomId());
		if (hotetroom.isRoomAvailability()) {
			hotetroom.setRoomAvailability(false);
			hotelService.createHotelRoom(hotetroom);
			modal.addAttribute("msg","Booking Confirmed!!");
		} else {
			modal.addAttribute("msg", "room is already Booked");
		}
		return "showbooking";

	}

	/*
	 * @RequestMapping(value = "/showbooking") public String
	 * showbooking(@ModelAttribute("admin") Admin admin) {
	 * 
	 * return "showbooking"; }
	 */

}
