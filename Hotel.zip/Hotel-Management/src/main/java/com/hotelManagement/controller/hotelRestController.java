package com.hotelManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelManagement.models.Admin;
import com.hotelManagement.service.IAdminService;

@RestController
public class hotelRestController {
	
	@Autowired
	IAdminService adminService;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@PostMapping("/create")
	public void Create() {
		Admin a = new Admin("superadmin",passwordEncoder.encode("superadmin"), "SUPERADMIN");
		/*Admin a1 = new Admin("ankita123",passwordEncoder.encode("ankita123"), "ADMIN");*/
		adminService.create(a);
//		adminService.create(a1);


	}

}
